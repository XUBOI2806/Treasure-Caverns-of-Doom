/*************************************************
  Project: Treasure Caverns of Doom
  Author: Felix Xu
  Purpose: Consumable Class Definition File
 **************************************************/

#include "Consumable.h"

 // Using consumable on player
void Consumable::use(Player* player) {
	cout << "wrong usage";
}